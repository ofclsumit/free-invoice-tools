import type { QuotationFormData } from "@/components/quotation/quotation-generator"

interface QuotationPDFData extends QuotationFormData {
  subtotal: number
  totalTax: number
  totalDiscount: number
  grandTotal: number
  itemsWithTotals: Array<{
    description: string
    quantity: number
    unit?: string
    rate: number
    discount: number
    taxRate: number
    taxableAmount: number
    taxAmount: number
    total: number
  }>
}

const fmt = (n: number) => n.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })

function formatDate(dateStr: string): string {
  if (!dateStr) return ""
  try {
    return new Date(dateStr).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" })
  } catch { return dateStr }
}

export async function generateQuotationPDF(data: QuotationPDFData): Promise<void> {
  const { jsPDF } = await import("jspdf")
  const { default: autoTable } = await import("jspdf-autotable")

  const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" })
  const pageW = doc.internal.pageSize.getWidth()
  const margin = 15
  const contentW = pageW - margin * 2
  let y = margin

  // Header bar - violet for quotations
  doc.setFillColor(124, 58, 237)
  doc.roundedRect(margin, y, contentW, 28, 4, 4, "F")
  doc.setFont("helvetica", "bold"); doc.setFontSize(18); doc.setTextColor(255, 255, 255)
  doc.text(data.businessName || "Your Business", margin + 6, y + 11)
  doc.setFontSize(20)
  doc.text("QUOTATION", pageW - margin - 6, y + 11, { align: "right" })
  doc.setFontSize(9); doc.setFont("helvetica", "normal")
  doc.text(`#${data.quoteNumber || "QUO-0001"}`, pageW - margin - 6, y + 19, { align: "right" })
  y += 34

  // Business info
  const col2X = pageW / 2 + 2
  doc.setFontSize(8); doc.setFont("helvetica", "normal")
  if (data.businessGstin) { doc.setTextColor(107,114,128); doc.text(`GSTIN: ${data.businessGstin}`, margin, y); y += 4 }
  if (data.businessAddress) {
    const lines = doc.splitTextToSize(data.businessAddress, contentW/2-10)
    doc.setTextColor(55,65,81)
    lines.forEach((l: string) => { doc.text(l, margin, y); y += 3.5 })
  }
  if (data.businessPhone) { doc.setTextColor(107,114,128); doc.text(data.businessPhone, margin, y); y += 3.5 }
  if (data.businessEmail) { doc.text(data.businessEmail, margin, y) }

  // Client box
  let clientY = margin + 34
  doc.setFontSize(7); doc.setFont("helvetica", "bold"); doc.setTextColor(124, 58, 237)
  doc.text("QUOTE FOR", col2X, clientY); clientY += 4
  doc.setFillColor(250,245,255); doc.setDrawColor(221,214,254)
  doc.roundedRect(col2X, clientY, contentW/2-2, 28, 2, 2, "FD")
  clientY += 5
  doc.setFontSize(10); doc.setFont("helvetica", "bold"); doc.setTextColor(17,24,39)
  doc.text(data.clientName || "Client Name", col2X + 4, clientY); clientY += 5
  doc.setFontSize(7.5); doc.setFont("helvetica", "normal")
  if (data.clientAddress) {
    const lines = doc.splitTextToSize(data.clientAddress, contentW/2-12)
    doc.setTextColor(55,65,81)
    lines.slice(0,2).forEach((l: string) => { doc.text(l, col2X+4, clientY); clientY += 3.5 })
  }
  if (data.clientEmail) { doc.setTextColor(107,114,128); doc.text(data.clientEmail, col2X+4, clientY); clientY += 3.5 }
  doc.text(`Date: ${formatDate(data.quoteDate)}`, col2X+4, clientY); clientY += 3.5
  if (data.validUntil) { doc.setTextColor(239,68,68); doc.text(`Valid until: ${formatDate(data.validUntil)}`, col2X+4, clientY) }

  y += 24
  if (data.subject) {
    doc.setFontSize(10); doc.setFont("helvetica", "bold"); doc.setTextColor(91,33,182)
    doc.text(`Re: ${data.subject}`, margin, y); y += 6
  }

  // Items table
  const tableRows = data.itemsWithTotals.map((item, i) => [
    String(i + 1),
    item.description + (item.discount > 0 ? `\n(Disc: ${item.discount}%)` : ""),
    `${item.quantity}${item.unit ? " " + item.unit : ""}`,
    `₹${fmt(item.rate)}`,
    item.taxRate > 0 ? `${item.taxRate}%` : "—",
    `₹${fmt(item.total)}`,
  ])

  autoTable(doc, {
    startY: y,
    head: [["#", "Description", "Qty", "Rate", "Tax", "Amount"]],
    body: tableRows,
    margin: { left: margin, right: margin },
    styles: { fontSize: 8, cellPadding: 3, textColor: [31, 41, 55] },
    headStyles: { fillColor: [91, 33, 182], textColor: [255, 255, 255], fontStyle: "bold", fontSize: 8 },
    alternateRowStyles: { fillColor: [250, 245, 255] },
    columnStyles: {
      0: { cellWidth: 8, halign: "center" }, 1: { cellWidth: "auto" },
      2: { cellWidth: 20, halign: "center" }, 3: { cellWidth: 24, halign: "right" },
      4: { cellWidth: 16, halign: "center" }, 5: { cellWidth: 26, halign: "right", fontStyle: "bold" },
    },
  })

  y = (doc as any).lastAutoTable.finalY + 6

  // Totals
  const totalsX = pageW - margin - 72
  doc.setFillColor(250,245,255); doc.setDrawColor(221,214,254)
  doc.roundedRect(totalsX, y, 72, data.totalDiscount > 0 ? 28 : 22, 3, 3, "FD")
  let tY = y + 5
  doc.setFontSize(8)
  if (data.totalDiscount > 0) {
    doc.setFont("helvetica","normal"); doc.setTextColor(107,114,128)
    doc.text("Discount", totalsX+4, tY); doc.setTextColor(31,41,55); doc.text(`-₹${fmt(data.totalDiscount)}`, totalsX+68, tY, {align:"right"}); tY += 6
  }
  if (data.totalTax > 0) {
    doc.setFont("helvetica","normal"); doc.setTextColor(107,114,128)
    doc.text("Tax", totalsX+4, tY); doc.setTextColor(31,41,55); doc.text(`₹${fmt(data.totalTax)}`, totalsX+68, tY, {align:"right"}); tY += 6
  }
  doc.setFillColor(124,58,237)
  doc.roundedRect(totalsX, tY, 72, 11, 2, 2, "F")
  doc.setFont("helvetica","bold"); doc.setFontSize(9); doc.setTextColor(255,255,255)
  doc.text("TOTAL", totalsX+4, tY+7)
  doc.text(`₹${fmt(data.grandTotal)}`, totalsX+68, tY+7, {align:"right"})
  y = tY + 16

  // Notes & Terms
  if (data.notes) {
    doc.setFontSize(7); doc.setFont("helvetica","bold"); doc.setTextColor(124,58,237)
    doc.text("NOTES", margin, y); y += 4
    doc.setFont("helvetica","normal"); doc.setTextColor(55,65,81)
    doc.splitTextToSize(data.notes, contentW).slice(0,3).forEach((l: string) => { doc.text(l, margin, y); y += 3.5 })
    y += 2
  }
  if (data.terms) {
    doc.setFontSize(7); doc.setFont("helvetica","bold"); doc.setTextColor(124,58,237)
    doc.text("TERMS & CONDITIONS", margin, y); y += 4
    doc.setFont("helvetica","normal"); doc.setTextColor(55,65,81)
    doc.splitTextToSize(data.terms, contentW).slice(0,3).forEach((l: string) => { doc.text(l, margin, y); y += 3.5 })
  }

  // Footer
  const pageH = doc.internal.pageSize.getHeight()
  const footerY = pageH - 18
  doc.setDrawColor(229,231,235); doc.line(margin, footerY, pageW-margin, footerY)
  doc.setFontSize(7); doc.setFont("helvetica","normal"); doc.setTextColor(156,163,175)
  doc.text("Generated by QuoteFlow · quoteflow.in", margin, footerY+5)
  doc.setDrawColor(209,213,219); doc.line(pageW-margin-45, footerY+8, pageW-margin, footerY+8)
  doc.text("Authorised Signature", pageW-margin-22, footerY+5, {align:"center"})
  doc.setFont("helvetica","bold"); doc.setTextColor(31,41,55)
  doc.text(data.businessName || "", pageW-margin-22, footerY+12, {align:"center"})

  const fileName = `${data.quoteNumber || "quotation"}-${data.clientName || "client"}.pdf`.replace(/\s+/g,"-").toLowerCase()
  doc.save(fileName)
}
