import type { InvoiceFormData } from "@/components/invoice/invoice-generator"

interface InvoicePDFData extends InvoiceFormData {
  subtotal: number
  totalCgst: number
  totalSgst: number
  totalIgst: number
  totalTax: number
  grandTotal: number
  totalDiscount: number
  itemsWithTotals: Array<{
    description: string
    hsnCode?: string
    quantity: number
    unit?: string
    rate: number
    discount: number
    gstRate: number
    gstType: string
    taxableAmount: number
    cgst: number
    sgst: number
    igst: number
    taxAmount: number
    total: number
    discountAmount?: number
  }>
}

function numToWords(num: number): string {
  const ones = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
    "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"]
  const tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"]
  if (num === 0) return "Zero"
  const inWords = (n: number): string => {
    if (n < 20) return ones[n]
    if (n < 100) return tens[Math.floor(n / 10)] + (n % 10 ? " " + ones[n % 10] : "")
    if (n < 1000) return ones[Math.floor(n / 100)] + " Hundred" + (n % 100 ? " " + inWords(n % 100) : "")
    if (n < 100000) return inWords(Math.floor(n / 1000)) + " Thousand" + (n % 1000 ? " " + inWords(n % 1000) : "")
    if (n < 10000000) return inWords(Math.floor(n / 100000)) + " Lakh" + (n % 100000 ? " " + inWords(n % 100000) : "")
    return inWords(Math.floor(n / 10000000)) + " Crore" + (n % 10000000 ? " " + inWords(n % 10000000) : "")
  }
  const intPart = Math.floor(num)
  const decPart = Math.round((num - intPart) * 100)
  let result = inWords(intPart) + " Rupees"
  if (decPart > 0) result += " and " + inWords(decPart) + " Paise"
  return result + " Only"
}

function formatDate(dateStr: string): string {
  if (!dateStr) return ""
  try {
    return new Date(dateStr).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" })
  } catch { return dateStr }
}

const fmt = (n: number) => n.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })

export async function generateInvoicePDF(data: InvoicePDFData): Promise<void> {
  const { jsPDF } = await import("jspdf")
  const { default: autoTable } = await import("jspdf-autotable")

  const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" })
  const pageW = doc.internal.pageSize.getWidth()
  const margin = 15
  const contentW = pageW - margin * 2
  let y = margin

  // Header bar
  doc.setFillColor(37, 99, 235)
  doc.roundedRect(margin, y, contentW, 28, 4, 4, "F")
  doc.setFont("helvetica", "bold")
  doc.setFontSize(18)
  doc.setTextColor(255, 255, 255)
  doc.text(data.businessName || "Your Business", margin + 6, y + 11)
  doc.setFontSize(22)
  doc.text("INVOICE", pageW - margin - 6, y + 12, { align: "right" })
  doc.setFontSize(9)
  doc.setFont("helvetica", "normal")
  doc.text(`#${data.invoiceNumber || "INV-0001"}`, pageW - margin - 6, y + 19, { align: "right" })
  y += 34

  const col2X = pageW / 2 + 2
  let leftY = y

  // Business details
  doc.setFontSize(8)
  doc.setFont("helvetica", "normal")
  if (data.businessGstin) {
    doc.setTextColor(107, 114, 128)
    doc.text(`GSTIN: ${data.businessGstin}`, margin, leftY); leftY += 4
  }
  if (data.businessAddress) {
    const lines = doc.splitTextToSize(data.businessAddress, contentW / 2 - 10)
    doc.setTextColor(55, 65, 81)
    lines.forEach((l: string) => { doc.text(l, margin, leftY); leftY += 3.5 })
  }
  if (data.businessPhone) { doc.setTextColor(107,114,128); doc.text(data.businessPhone, margin, leftY); leftY += 3.5 }
  if (data.businessEmail) { doc.text(data.businessEmail, margin, leftY) }

  // Client box
  let clientY = y
  doc.setFontSize(7); doc.setFont("helvetica", "bold"); doc.setTextColor(37, 99, 235)
  doc.text("BILL TO", col2X, clientY); clientY += 4
  doc.setFillColor(248, 250, 255); doc.setDrawColor(224, 231, 255)
  doc.roundedRect(col2X, clientY, contentW / 2 - 2, 30, 2, 2, "FD")
  clientY += 5
  doc.setFontSize(10); doc.setFont("helvetica", "bold"); doc.setTextColor(17, 24, 39)
  doc.text(data.clientName || "Client Name", col2X + 4, clientY); clientY += 5
  doc.setFontSize(7.5); doc.setFont("helvetica", "normal")
  if (data.clientGstin) { doc.setTextColor(107,114,128); doc.text(`GSTIN: ${data.clientGstin}`, col2X+4, clientY); clientY += 3.5 }
  if (data.clientAddress) {
    const lines = doc.splitTextToSize(data.clientAddress, contentW / 2 - 12)
    doc.setTextColor(55, 65, 81)
    lines.slice(0, 3).forEach((l: string) => { doc.text(l, col2X+4, clientY); clientY += 3.5 })
  }
  if (data.clientEmail) { doc.setTextColor(107,114,128); doc.text(data.clientEmail, col2X+4, clientY); clientY += 3.5 }
  doc.text(`Invoice Date: ${formatDate(data.invoiceDate)}`, col2X+4, clientY); clientY += 3.5
  if (data.dueDate) { doc.setTextColor(239,68,68); doc.text(`Due Date: ${formatDate(data.dueDate)}`, col2X+4, clientY) }

  y += 28

  // Items table
  const tableRows = data.itemsWithTotals.map((item, i) => [
    String(i + 1),
    item.description + (item.discount > 0 ? `\n(Disc: ${item.discount}%)` : ""),
    item.hsnCode || "—",
    `${item.quantity}${item.unit ? " " + item.unit : ""}`,
    `₹${fmt(item.rate)}`,
    item.gstType === "CGST_SGST" ? `${item.gstRate}%(C+S)` : item.gstType === "IGST" ? `${item.gstRate}% IGST` : "Exempt",
    `₹${fmt(item.total)}`,
  ])

  autoTable(doc, {
    startY: y,
    head: [["#", "Description", "HSN/SAC", "Qty", "Rate", "GST", "Amount"]],
    body: tableRows,
    margin: { left: margin, right: margin },
    styles: { fontSize: 8, cellPadding: 3, textColor: [31, 41, 55] },
    headStyles: { fillColor: [30, 58, 138], textColor: [255, 255, 255], fontStyle: "bold", fontSize: 8 },
    alternateRowStyles: { fillColor: [249, 250, 251] },
    columnStyles: {
      0: { cellWidth: 8, halign: "center" }, 1: { cellWidth: "auto" },
      2: { cellWidth: 20, halign: "center" }, 3: { cellWidth: 18, halign: "center" },
      4: { cellWidth: 22, halign: "right" }, 5: { cellWidth: 18, halign: "center" },
      6: { cellWidth: 24, halign: "right", fontStyle: "bold" },
    },
  })

  y = (doc as any).lastAutoTable.finalY + 6

  // Totals box
  const totalsX = pageW - margin - 72
  const tW = 72
  const totalsRows: Array<[string, string]> = [
    ["Subtotal", `₹${fmt(data.subtotal)}`],
    ...(data.totalDiscount > 0 ? [["Discount", `-₹${fmt(data.totalDiscount)}`] as [string,string]] : []),
    ...(data.totalCgst > 0 ? [["CGST", `₹${fmt(data.totalCgst)}`] as [string,string]] : []),
    ...(data.totalSgst > 0 ? [["SGST", `₹${fmt(data.totalSgst)}`] as [string,string]] : []),
    ...(data.totalIgst > 0 ? [["IGST", `₹${fmt(data.totalIgst)}`] as [string,string]] : []),
  ]
  const tH = totalsRows.length * 6 + 14
  doc.setFillColor(248, 250, 255); doc.setDrawColor(224, 231, 255)
  doc.roundedRect(totalsX, y, tW, tH, 3, 3, "FD")
  let tY = y + 5
  doc.setFontSize(8)
  totalsRows.forEach(([label, value]) => {
    doc.setFont("helvetica", "normal"); doc.setTextColor(107, 114, 128)
    doc.text(label, totalsX + 4, tY)
    doc.setTextColor(31, 41, 55); doc.text(value, totalsX + tW - 4, tY, { align: "right" })
    tY += 6
  })
  doc.setFillColor(37, 99, 235)
  doc.roundedRect(totalsX, tY, tW, 11, 2, 2, "F")
  doc.setFont("helvetica", "bold"); doc.setFontSize(9); doc.setTextColor(255, 255, 255)
  doc.text("TOTAL", totalsX + 4, tY + 7)
  doc.text(`₹${fmt(data.grandTotal)}`, totalsX + tW - 4, tY + 7, { align: "right" })
  y = tY + 16

  // Amount in words
  doc.setFillColor(239, 246, 255); doc.setDrawColor(191, 219, 254)
  doc.roundedRect(margin, y, contentW, 9, 2, 2, "FD")
  doc.setFontSize(7.5); doc.setFont("helvetica", "bold"); doc.setTextColor(30, 64, 175)
  doc.text("Amount in words: ", margin + 4, y + 5.5)
  doc.setFont("helvetica", "normal"); doc.setTextColor(55, 65, 81)
  doc.text(numToWords(data.grandTotal), margin + 36, y + 5.5)
  y += 14

  // Notes & Terms
  if (data.notes) {
    doc.setFontSize(7); doc.setFont("helvetica", "bold"); doc.setTextColor(37, 99, 235)
    doc.text("NOTES", margin, y); y += 4
    doc.setFont("helvetica", "normal"); doc.setTextColor(55, 65, 81)
    const noteLines = doc.splitTextToSize(data.notes, contentW / 2 - 4)
    noteLines.slice(0, 4).forEach((l: string) => { doc.text(l, margin, y); y += 3.5 })
    y += 2
  }
  if (data.terms) {
    doc.setFontSize(7); doc.setFont("helvetica", "bold"); doc.setTextColor(37, 99, 235)
    doc.text("TERMS & CONDITIONS", margin, y); y += 4
    doc.setFont("helvetica", "normal"); doc.setTextColor(55, 65, 81)
    const termLines = doc.splitTextToSize(data.terms, contentW)
    termLines.slice(0, 3).forEach((l: string) => { doc.text(l, margin, y); y += 3.5 })
    y += 2
  }

  // UPI QR Code
  if (data.upiId) {
    try {
      const QRCode = await import("qrcode")
      const upiUrl = `upi://pay?pa=${data.upiId}&pn=${encodeURIComponent(data.businessName || "")}&am=${data.grandTotal}&cu=INR`
      const qrDataUrl = await QRCode.toDataURL(upiUrl, { width: 80, margin: 1 })
      const qrX = pageW - margin - 25
      const qrY = y - 22
      doc.addImage(qrDataUrl, "PNG", qrX, qrY, 22, 22)
      doc.setFontSize(7); doc.setFont("helvetica", "normal"); doc.setTextColor(107, 114, 128)
      doc.text("Scan to Pay", qrX + 11, qrY + 24, { align: "center" })
      doc.text(data.upiId, qrX + 11, qrY + 27.5, { align: "center" })
    } catch (err) { console.warn("QR generation failed:", err) }
  }

  // Footer
  const pageH = doc.internal.pageSize.getHeight()
  const footerY = pageH - 18
  doc.setDrawColor(229, 231, 235); doc.line(margin, footerY, pageW - margin, footerY)
  doc.setFontSize(7); doc.setFont("helvetica", "normal"); doc.setTextColor(156, 163, 175)
  doc.text("Generated by QuoteFlow · quoteflow.in", margin, footerY + 5)
  doc.setDrawColor(209, 213, 219); doc.line(pageW - margin - 45, footerY + 8, pageW - margin, footerY + 8)
  doc.text("Authorised Signature", pageW - margin - 22, footerY + 5, { align: "center" })
  doc.setFont("helvetica", "bold"); doc.setTextColor(31, 41, 55)
  doc.text(data.businessName || "", pageW - margin - 22, footerY + 12, { align: "center" })

  const fileName = `${data.invoiceNumber || "invoice"}-${data.clientName || "client"}.pdf`
    .replace(/\s+/g, "-").toLowerCase()
  doc.save(fileName)
}
