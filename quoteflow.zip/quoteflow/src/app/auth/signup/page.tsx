"use client"
import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Zap, Mail, Lock, User, ArrowRight, Chrome, CheckCircle2 } from "lucide-react"

export default function SignUpPage() {
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    await new Promise(r => setTimeout(r, 1000))
    window.location.href = "/dashboard"
  }

  return (
    <div className="min-h-screen bg-mesh flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <Link href="/" className="flex items-center gap-2.5 font-display font-bold text-xl mb-8 justify-center">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-blue-600 to-violet-600">
            <Zap className="h-4 w-4 text-white" />
          </div>
          <span className="bg-gradient-to-r from-blue-600 to-violet-600 bg-clip-text text-transparent">QuoteFlow</span>
        </Link>

        <div className="bg-white dark:bg-gray-900 rounded-2xl border border-border p-7 shadow-glass">
          <h1 className="text-2xl font-display font-bold mb-1.5">Create your account</h1>
          <p className="text-sm text-muted-foreground mb-6">Free forever. No credit card required.</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">Full Name</Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Ravi Kumar" required className="h-10 pl-9 text-sm" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input type="email" placeholder="you@business.com" required className="h-10 pl-9 text-sm" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input type="password" placeholder="Min. 8 characters" required className="h-10 pl-9 text-sm" />
              </div>
            </div>
            <Button type="submit" disabled={loading} className="w-full h-10 bg-gradient-to-r from-blue-600 to-violet-600 text-white border-0 font-semibold gap-2">
              {loading ? "Creating account…" : <>Create Free Account <ArrowRight className="h-4 w-4" /></>}
            </Button>
          </form>

          <div className="relative my-5">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-border" /></div>
            <div className="relative flex justify-center text-xs uppercase"><span className="bg-white dark:bg-gray-900 px-3 text-muted-foreground">or</span></div>
          </div>

          <Button variant="outline" className="w-full h-10 gap-2 text-sm" onClick={() => window.location.href = "/dashboard"}>
            <Chrome className="h-4 w-4" /> Continue with Google
          </Button>

          <ul className="mt-5 space-y-1.5">
            {["No credit card needed","Free 25 invoices per month","No watermarks on PDFs"].map(b => (
              <li key={b} className="flex items-center gap-2 text-xs text-muted-foreground">
                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500 flex-shrink-0" />
                {b}
              </li>
            ))}
          </ul>

          <p className="text-center text-xs text-muted-foreground mt-5">
            Already have an account?{" "}
            <Link href="/auth/signin" className="text-blue-600 font-medium hover:underline">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
