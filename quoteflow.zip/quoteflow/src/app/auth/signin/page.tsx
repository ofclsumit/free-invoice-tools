"use client"
import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Zap, Mail, Lock, ArrowRight, Chrome } from "lucide-react"

export default function SignInPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    await new Promise(r => setTimeout(r, 800))
    window.location.href = "/dashboard"
  }

  return (
    <div className="min-h-screen bg-mesh flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <Link href="/" className="flex items-center gap-2.5 font-display font-bold text-xl mb-8 justify-center">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-blue-600 to-violet-600">
            <Zap className="h-4 w-4 text-white" />
          </div>
          <span className="bg-gradient-to-r from-blue-600 to-violet-600 bg-clip-text text-transparent">QuoteFlow</span>
        </Link>

        <div className="bg-white dark:bg-gray-900 rounded-2xl border border-border p-7 shadow-glass">
          <h1 className="text-2xl font-display font-bold mb-1.5">Welcome back</h1>
          <p className="text-sm text-muted-foreground mb-6">Sign in to your QuoteFlow account</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input type="email" placeholder="you@business.com" value={email} onChange={e => setEmail(e.target.value)} required className="h-10 pl-9 text-sm" />
              </div>
            </div>
            <div className="space-y-1.5">
              <div className="flex justify-between">
                <Label className="text-xs font-medium">Password</Label>
                <Link href="/auth/forgot-password" className="text-xs text-blue-600 hover:underline">Forgot password?</Link>
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input type="password" placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} required className="h-10 pl-9 text-sm" />
              </div>
            </div>
            <Button type="submit" disabled={loading} className="w-full h-10 bg-gradient-to-r from-blue-600 to-violet-600 text-white border-0 font-semibold gap-2">
              {loading ? "Signing in…" : <>Sign In <ArrowRight className="h-4 w-4" /></>}
            </Button>
          </form>

          <div className="relative my-5">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-border" /></div>
            <div className="relative flex justify-center text-xs uppercase"><span className="bg-white dark:bg-gray-900 px-3 text-muted-foreground">or</span></div>
          </div>

          <Button variant="outline" className="w-full h-10 gap-2 text-sm" onClick={() => window.location.href = "/dashboard"}>
            <Chrome className="h-4 w-4" /> Continue with Google
          </Button>

          <p className="text-center text-xs text-muted-foreground mt-5">
            Don't have an account?{" "}
            <Link href="/auth/signup" className="text-blue-600 font-medium hover:underline">Sign up free</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
