import { Suspense } from "react"
import { DashboardStats } from "@/components/dashboard/stats"
import { RecentInvoices } from "@/components/dashboard/recent-invoices"
import { RecentQuotations } from "@/components/dashboard/recent-quotations"
import { RevenueChart } from "@/components/dashboard/revenue-chart"
import { QuickActions } from "@/components/dashboard/quick-actions"
import { StatsSkeleton } from "@/components/dashboard/skeletons"

export const metadata = { title: "Dashboard" }

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-display font-bold tracking-tight">Good morning 👋</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Here's what's happening with your business today.</p>
        </div>
        <QuickActions />
      </div>

      {/* Stats */}
      <Suspense fallback={<StatsSkeleton />}>
        <DashboardStats />
      </Suspense>

      {/* Charts and activity */}
      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <RevenueChart />
        </div>
        <div>
          <RecentQuotations />
        </div>
      </div>

      {/* Recent invoices */}
      <RecentInvoices />
    </div>
  )
}
