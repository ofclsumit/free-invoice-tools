import { QuotationGenerator } from "@/components/quotation/quotation-generator"
export const metadata = { title: "New Quotation" }
export default function NewQuotationPage() {
  return <QuotationGenerator />
}
