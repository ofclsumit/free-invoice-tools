"use client"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Separator } from "@/components/ui/separator"
import { Save, Building2, CreditCard, Bell, Shield, Palette } from "lucide-react"

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState("business")

  const tabs = [
    { id: "business", label: "Business", icon: Building2 },
    { id: "billing", label: "Bank & UPI", icon: CreditCard },
    { id: "appearance", label: "Appearance", icon: Palette },
    { id: "notifications", label: "Notifications", icon: Bell },
    { id: "security", label: "Security", icon: Shield },
  ]

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-2xl font-display font-bold tracking-tight">Settings</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Manage your account and business preferences</p>
      </div>

      <div className="flex gap-6">
        {/* Sidebar tabs */}
        <nav className="hidden sm:flex flex-col gap-1 w-44 flex-shrink-0">
          {tabs.map(tab => {
            const Icon = tab.icon
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium transition-all text-left ${
                  activeTab === tab.id ? "bg-primary/10 text-primary font-semibold" : "text-muted-foreground hover:text-foreground hover:bg-accent"
                }`}
              >
                <Icon className="h-4 w-4 flex-shrink-0" />
                {tab.label}
              </button>
            )
          })}
        </nav>

        {/* Content */}
        <div className="flex-1 min-w-0">
          {activeTab === "business" && (
            <div className="form-section space-y-6">
              <h2 className="font-display font-semibold">Business Information</h2>
              <p className="text-sm text-muted-foreground -mt-4">This information will appear on all your invoices and quotations.</p>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">Business Name</Label>
                  <Input defaultValue="Acme Design Studio" className="h-9 text-sm" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">GSTIN</Label>
                  <Input defaultValue="27ABCDE1234F1Z5" className="h-9 text-sm font-mono" />
                </div>
                <div className="sm:col-span-2 space-y-1.5">
                  <Label className="text-xs font-medium">Address</Label>
                  <Textarea rows={2} defaultValue="123, Business Park, Andheri West, Mumbai - 400053" className="text-sm resize-none" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">Phone</Label>
                  <Input defaultValue="+91 98765 43210" className="h-9 text-sm" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">Email</Label>
                  <Input defaultValue="hello@acmedesign.in" type="email" className="h-9 text-sm" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">Invoice Prefix</Label>
                  <Input defaultValue="INV" className="h-9 text-sm font-mono" placeholder="INV" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">Quotation Prefix</Label>
                  <Input defaultValue="QUO" className="h-9 text-sm font-mono" placeholder="QUO" />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">Default Terms & Conditions</Label>
                <Textarea rows={3} defaultValue="Payment is due within 30 days of invoice date. Late payments may incur interest at 2% per month." className="text-sm resize-none" />
              </div>
              <Button className="gap-2 bg-gradient-to-r from-blue-600 to-violet-600 text-white border-0 font-semibold">
                <Save className="h-4 w-4" /> Save Changes
              </Button>
            </div>
          )}

          {activeTab === "billing" && (
            <div className="form-section space-y-6">
              <h2 className="font-display font-semibold">Bank & UPI Details</h2>
              <p className="text-sm text-muted-foreground -mt-4">Used to generate UPI QR codes and display bank details on invoices.</p>
              <div className="space-y-4">
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">UPI ID</Label>
                  <Input placeholder="yourname@upi" className="h-9 text-sm" />
                  <p className="text-xs text-muted-foreground">A QR code will be auto-embedded in every invoice PDF</p>
                </div>
                <Separator />
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium">Bank Name</Label>
                    <Input placeholder="HDFC Bank" className="h-9 text-sm" />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium">Account Number</Label>
                    <Input placeholder="1234567890" className="h-9 text-sm font-mono" />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium">IFSC Code</Label>
                    <Input placeholder="HDFC0001234" className="h-9 text-sm font-mono" />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium">Account Holder Name</Label>
                    <Input placeholder="Acme Design Studio" className="h-9 text-sm" />
                  </div>
                </div>
              </div>
              <Button className="gap-2 bg-gradient-to-r from-blue-600 to-violet-600 text-white border-0 font-semibold">
                <Save className="h-4 w-4" /> Save Changes
              </Button>
            </div>
          )}

          {activeTab === "appearance" && (
            <div className="form-section space-y-6">
              <h2 className="font-display font-semibold">Appearance</h2>
              <p className="text-sm text-muted-foreground -mt-4">Customize how your documents look.</p>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-xs font-medium">Primary Color</Label>
                  <div className="flex gap-2 flex-wrap">
                    {["#2563eb","#7c3aed","#059669","#d97706","#dc2626","#0891b2"].map(c => (
                      <button key={c} className="h-8 w-8 rounded-full border-2 border-white shadow-md hover:scale-110 transition-transform" style={{backgroundColor: c}} />
                    ))}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-xs font-medium">Logo</Label>
                  <div className="border-2 border-dashed border-border rounded-xl p-8 text-center">
                    <p className="text-sm text-muted-foreground">Drop your logo here, or click to upload</p>
                    <p className="text-xs text-muted-foreground mt-1">PNG, JPG up to 2MB</p>
                    <Button variant="outline" size="sm" className="mt-3">Upload Logo</Button>
                  </div>
                </div>
              </div>
              <Button className="gap-2 bg-gradient-to-r from-blue-600 to-violet-600 text-white border-0 font-semibold">
                <Save className="h-4 w-4" /> Save Changes
              </Button>
            </div>
          )}

          {activeTab === "notifications" && (
            <div className="form-section">
              <h2 className="font-display font-semibold mb-4">Notifications</h2>
              <div className="space-y-4">
                {[
                  { label: "Invoice viewed notification", desc: "Get notified when a client opens your invoice" },
                  { label: "Payment received", desc: "Alert when a payment is recorded against an invoice" },
                  { label: "Invoice overdue reminders", desc: "Auto-reminders for overdue invoices" },
                  { label: "Weekly summary email", desc: "Weekly digest of your revenue and pending invoices" },
                ].map(n => (
                  <div key={n.label} className="flex items-center justify-between py-3 border-b border-border last:border-0">
                    <div>
                      <p className="text-sm font-medium">{n.label}</p>
                      <p className="text-xs text-muted-foreground">{n.desc}</p>
                    </div>
                    <div className="h-5 w-9 bg-blue-600 rounded-full flex items-center justify-end px-0.5 cursor-pointer">
                      <div className="h-4 w-4 bg-white rounded-full shadow" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === "security" && (
            <div className="form-section space-y-6">
              <h2 className="font-display font-semibold">Security</h2>
              <div className="space-y-4">
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">Current Password</Label>
                  <Input type="password" className="h-9 text-sm" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">New Password</Label>
                  <Input type="password" className="h-9 text-sm" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">Confirm New Password</Label>
                  <Input type="password" className="h-9 text-sm" />
                </div>
              </div>
              <Button className="gap-2 bg-gradient-to-r from-blue-600 to-violet-600 text-white border-0 font-semibold">
                <Save className="h-4 w-4" /> Update Password
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
