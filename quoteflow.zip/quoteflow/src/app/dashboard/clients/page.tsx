"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Plus, Search, Users, Mail, Phone, Building2, FileText, ClipboardList, MoreHorizontal, Edit, Trash2 } from "lucide-react"
import { getInitials } from "@/lib/utils"

const MOCK_CLIENTS = [
  { id: "1", name: "Ravi Enterprises", email: "ravi@ravienterprises.com", phone: "+91 98765 43210", gstin: "27AABCR1234F1Z5", city: "Mumbai", invoices: 12, totalBilled: 480000, lastInvoice: "15 Mar 2024" },
  { id: "2", name: "Sharma & Sons", email: "accounts@sharmasons.in", phone: "+91 99887 65432", gstin: "07AAACS0000A1Z3", city: "Delhi", invoices: 8, totalBilled: 320000, lastInvoice: "12 Mar 2024" },
  { id: "3", name: "Tech Solutions Pvt Ltd", email: "billing@techsol.com", phone: "+91 80765 43210", gstin: "29AATCS1234K1Z8", city: "Bangalore", invoices: 15, totalBilled: 890000, lastInvoice: "10 Mar 2024" },
  { id: "4", name: "Global Traders", email: "accounts@globaltraders.co.in", phone: "+91 70123 45678", gstin: "24AAACG5678L1Z2", city: "Ahmedabad", invoices: 5, totalBilled: 175000, lastInvoice: "8 Mar 2024" },
  { id: "5", name: "Patel Industries", email: "patel@patelindustries.com", phone: "+91 90876 54321", gstin: "24AAACP9012M1Z7", city: "Surat", invoices: 22, totalBilled: 1240000, lastInvoice: "5 Mar 2024" },
  { id: "6", name: "Future Tech Corp", email: "finance@futuretech.in", phone: "+91 88765 43210", gstin: "27AAAFT0000B1Z1", city: "Pune", invoices: 3, totalBilled: 95000, lastInvoice: "1 Mar 2024" },
]

const avatarColors = ["bg-blue-600","bg-violet-600","bg-emerald-600","bg-orange-600","bg-pink-600","bg-teal-600"]

export default function ClientsPage() {
  const [search, setSearch] = useState("")
  const filtered = MOCK_CLIENTS.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.email.toLowerCase().includes(search.toLowerCase()) ||
    c.city.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center gap-4 justify-between">
        <div>
          <h1 className="text-2xl font-display font-bold tracking-tight">Clients</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{MOCK_CLIENTS.length} clients total</p>
        </div>
        <Link href="/dashboard/clients/new">
          <Button className="gap-2 bg-gradient-to-r from-blue-600 to-violet-600 text-white border-0 font-semibold">
            <Plus className="h-4 w-4" /> Add Client
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: "Total Clients", value: "6", icon: Users, color: "text-blue-600", bg: "bg-blue-50 dark:bg-blue-950/30" },
          { label: "Total Billed", value: "₹32.0L", icon: Building2, color: "text-emerald-600", bg: "bg-emerald-50 dark:bg-emerald-950/30" },
          { label: "Avg per Client", value: "₹5.3L", icon: FileText, color: "text-violet-600", bg: "bg-violet-50 dark:bg-violet-950/30" },
          { label: "Active This Month", value: "4", icon: ClipboardList, color: "text-orange-600", bg: "bg-orange-50 dark:bg-orange-950/30" },
        ].map((s) => {
          const Icon = s.icon
          return (
            <div key={s.label} className="bg-white dark:bg-gray-900 rounded-2xl border border-border p-4">
              <div className={`h-9 w-9 rounded-xl ${s.bg} flex items-center justify-center mb-3`}>
                <Icon className={`h-4 w-4 ${s.color}`} />
              </div>
              <p className="font-display font-bold text-xl">{s.value}</p>
              <p className="text-xs text-muted-foreground">{s.label}</p>
            </div>
          )
        })}
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search clients…" value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 h-9 text-sm" />
      </div>

      <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map((client, i) => (
          <div key={client.id} className="bg-white dark:bg-gray-900 rounded-2xl border border-border p-5 hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 group">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className={`h-10 w-10 rounded-xl ${avatarColors[i % avatarColors.length]} flex items-center justify-center text-white font-display font-bold text-sm flex-shrink-0`}>
                  {getInitials(client.name)}
                </div>
                <div className="min-w-0">
                  <p className="font-display font-semibold text-sm truncate">{client.name}</p>
                  <p className="text-xs text-muted-foreground">{client.city}</p>
                </div>
              </div>
            </div>
            <div className="space-y-2 mb-4">
              {client.email && <div className="flex items-center gap-2 text-xs text-muted-foreground"><Mail className="h-3 w-3 flex-shrink-0" /><span className="truncate">{client.email}</span></div>}
              {client.phone && <div className="flex items-center gap-2 text-xs text-muted-foreground"><Phone className="h-3 w-3 flex-shrink-0" /><span>{client.phone}</span></div>}
              {client.gstin && <div className="flex items-center gap-2 text-xs text-muted-foreground"><Building2 className="h-3 w-3 flex-shrink-0" /><span className="font-mono">{client.gstin}</span></div>}
            </div>
            <div className="pt-4 border-t border-border flex items-center justify-between">
              <div>
                <p className="font-display font-bold text-sm">₹{(client.totalBilled / 100000).toFixed(1)}L</p>
                <p className="text-xs text-muted-foreground">{client.invoices} invoices</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-muted-foreground">Last invoice</p>
                <p className="text-xs font-medium">{client.lastInvoice}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-16">
          <Users className="h-12 w-12 text-muted-foreground/30 mx-auto mb-4" />
          <p className="font-display font-semibold text-lg">No clients found</p>
          <p className="text-sm text-muted-foreground mt-1">Try a different search or add a new client.</p>
        </div>
      )}
    </div>
  )
}
