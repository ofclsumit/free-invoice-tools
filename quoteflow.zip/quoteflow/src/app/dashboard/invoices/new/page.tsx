import { InvoiceGenerator } from "@/components/invoice/invoice-generator"

export const metadata = { title: "New Invoice" }

export default function NewInvoicePage() {
  return <InvoiceGenerator />
}
