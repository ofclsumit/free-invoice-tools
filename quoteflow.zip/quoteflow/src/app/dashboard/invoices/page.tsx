"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Plus, Search, Download, Send, Share2, MoreHorizontal, FileText, Filter } from "lucide-react"
import { cn } from "@/lib/utils"
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuTrigger, DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"

const INVOICES = [
  { id: "INV-0047", client: "Ravi Enterprises", amount: 59000, date: "15 Mar 2024", due: "15 Apr 2024", status: "paid" },
  { id: "INV-0046", client: "Sharma & Sons", amount: 124500, date: "12 Mar 2024", due: "12 Apr 2024", status: "sent" },
  { id: "INV-0045", client: "Tech Solutions Pvt", amount: 87200, date: "10 Mar 2024", due: "10 Apr 2024", status: "viewed" },
  { id: "INV-0044", client: "Global Traders", amount: 34800, date: "8 Mar 2024", due: "8 Apr 2024", status: "overdue" },
  { id: "INV-0043", client: "Patel Industries", amount: 215000, date: "5 Mar 2024", due: "5 Apr 2024", status: "paid" },
  { id: "INV-0042", client: "Future Tech Corp", amount: 48000, date: "1 Mar 2024", due: "1 Apr 2024", status: "draft" },
  { id: "INV-0041", client: "Modi Builders", amount: 340000, date: "25 Feb 2024", due: "25 Mar 2024", status: "overdue" },
  { id: "INV-0040", client: "Sunrise Hotels", amount: 165000, date: "20 Feb 2024", due: "20 Mar 2024", status: "paid" },
]

const statusConfig: Record<string, { label: string; className: string }> = {
  draft: { label: "Draft", className: "status-draft" },
  sent: { label: "Sent", className: "status-sent" },
  viewed: { label: "Viewed", className: "status-viewed" },
  paid: { label: "Paid", className: "status-paid" },
  overdue: { label: "Overdue", className: "status-overdue" },
}

const STATUS_FILTERS = ["all", "draft", "sent", "viewed", "paid", "overdue"]

export default function InvoicesPage() {
  const [search, setSearch] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")

  const filtered = INVOICES.filter(inv => {
    const matchSearch = inv.id.toLowerCase().includes(search.toLowerCase()) || inv.client.toLowerCase().includes(search.toLowerCase())
    const matchStatus = statusFilter === "all" || inv.status === statusFilter
    return matchSearch && matchStatus
  })

  const totalAmount = filtered.reduce((sum, inv) => sum + inv.amount, 0)
  const paidAmount = filtered.filter(i => i.status === "paid").reduce((sum, i) => sum + i.amount, 0)
  const pendingAmount = filtered.filter(i => ["sent","viewed"].includes(i.status)).reduce((sum, i) => sum + i.amount, 0)
  const overdueAmount = filtered.filter(i => i.status === "overdue").reduce((sum, i) => sum + i.amount, 0)

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center gap-4 justify-between">
        <div>
          <h1 className="text-2xl font-display font-bold tracking-tight">Invoices</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{INVOICES.length} invoices total</p>
        </div>
        <Link href="/dashboard/invoices/new">
          <Button className="gap-2 bg-gradient-to-r from-blue-600 to-violet-600 text-white border-0 font-semibold">
            <Plus className="h-4 w-4" /> New Invoice
          </Button>
        </Link>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: "Total Value", value: `₹${(totalAmount/100000).toFixed(1)}L`, color: "text-blue-600", bg: "bg-blue-50 dark:bg-blue-950/30" },
          { label: "Paid", value: `₹${(paidAmount/100000).toFixed(1)}L`, color: "text-emerald-600", bg: "bg-emerald-50 dark:bg-emerald-950/30" },
          { label: "Pending", value: `₹${(pendingAmount/1000).toFixed(0)}K`, color: "text-amber-600", bg: "bg-amber-50 dark:bg-amber-950/30" },
          { label: "Overdue", value: `₹${(overdueAmount/100000).toFixed(1)}L`, color: "text-red-600", bg: "bg-red-50 dark:bg-red-950/30" },
        ].map(s => (
          <div key={s.label} className={`rounded-2xl border border-border p-4 ${s.bg}`}>
            <p className={`font-display font-bold text-xl ${s.color}`}>{s.value}</p>
            <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search invoices…" value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 h-9 text-sm" />
        </div>
        <div className="flex gap-1.5 flex-wrap">
          {STATUS_FILTERS.map(s => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={cn(
                "px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-all",
                statusFilter === s
                  ? "bg-foreground text-background"
                  : "bg-muted text-muted-foreground hover:text-foreground hover:bg-muted/80"
              )}
            >
              {s === "all" ? "All" : statusConfig[s]?.label}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-gray-900 rounded-2xl border border-border overflow-hidden">
        <div className="hidden sm:grid grid-cols-[1fr_140px_120px_100px_120px] gap-4 px-6 py-3 text-xs font-medium text-muted-foreground border-b border-border bg-gray-50/50 dark:bg-gray-800/30">
          <span>Invoice</span><span>Client</span><span>Amount</span><span>Status</span><span>Date</span>
        </div>

        <div className="divide-y divide-border">
          {filtered.map((inv) => {
            const s = statusConfig[inv.status]
            return (
              <div key={inv.id} className="grid grid-cols-1 sm:grid-cols-[1fr_140px_120px_100px_120px] gap-2 sm:gap-4 items-center px-6 py-4 hover:bg-gray-50/50 dark:hover:bg-gray-800/30 transition-colors group">
                <div>
                  <span className="font-mono text-xs text-muted-foreground">{inv.id}</span>
                  <p className="font-medium text-sm">{inv.client}</p>
                </div>
                <span className="text-sm hidden sm:block">{inv.client}</span>
                <span className="font-display font-semibold text-sm">₹{inv.amount.toLocaleString("en-IN")}</span>
                <Badge variant="outline" className={cn("text-xs w-fit border capitalize", s.className)}>{s.label}</Badge>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">{inv.date}</span>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-44">
                      <DropdownMenuItem className="gap-2"><Download className="h-3.5 w-3.5" /> Download PDF</DropdownMenuItem>
                      <DropdownMenuItem className="gap-2"><Send className="h-3.5 w-3.5" /> Send Email</DropdownMenuItem>
                      <DropdownMenuItem className="gap-2"><Share2 className="h-3.5 w-3.5" /> WhatsApp</DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="gap-2"><FileText className="h-3.5 w-3.5" /> Duplicate</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-16">
          <FileText className="h-12 w-12 text-muted-foreground/30 mx-auto mb-4" />
          <p className="font-display font-semibold text-lg">No invoices found</p>
          <p className="text-sm text-muted-foreground mt-1">Create your first invoice to get started.</p>
          <Link href="/dashboard/invoices/new">
            <Button className="mt-4 gap-2 bg-gradient-to-r from-blue-600 to-violet-600 text-white border-0">
              <Plus className="h-4 w-4" /> Create Invoice
            </Button>
          </Link>
        </div>
      )}
    </div>
  )
}
