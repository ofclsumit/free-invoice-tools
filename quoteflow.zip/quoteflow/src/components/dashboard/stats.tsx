"use client"

import { TrendingUp, TrendingDown, FileText, IndianRupee, Clock, CheckCircle } from "lucide-react"
import { cn } from "@/lib/utils"

const stats = [
  {
    label: "Total Revenue",
    value: "₹4,82,000",
    change: "+12.5%",
    trend: "up",
    period: "vs last month",
    icon: IndianRupee,
    color: "text-emerald-600",
    bgColor: "bg-emerald-50 dark:bg-emerald-950/30",
    gradientFrom: "from-emerald-500",
    gradientTo: "to-teal-600",
  },
  {
    label: "Pending Payment",
    value: "₹1,24,500",
    change: "8 invoices",
    trend: "neutral",
    period: "awaiting payment",
    icon: Clock,
    color: "text-amber-600",
    bgColor: "bg-amber-50 dark:bg-amber-950/30",
    gradientFrom: "from-amber-500",
    gradientTo: "to-orange-600",
  },
  {
    label: "Invoices Sent",
    value: "47",
    change: "+8",
    trend: "up",
    period: "this month",
    icon: FileText,
    color: "text-blue-600",
    bgColor: "bg-blue-50 dark:bg-blue-950/30",
    gradientFrom: "from-blue-500",
    gradientTo: "to-indigo-600",
  },
  {
    label: "Paid Invoices",
    value: "39",
    change: "83% rate",
    trend: "up",
    period: "collection rate",
    icon: CheckCircle,
    color: "text-violet-600",
    bgColor: "bg-violet-50 dark:bg-violet-950/30",
    gradientFrom: "from-violet-500",
    gradientTo: "to-purple-600",
  },
]

export function DashboardStats() {
  return (
    <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-4">
      {stats.map((stat) => {
        const Icon = stat.icon
        return (
          <div key={stat.label} className="metric-card">
            {/* Gradient accent line */}
            <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${stat.gradientFrom} ${stat.gradientTo} rounded-t-2xl`} />

            <div className="flex items-start justify-between mb-4">
              <div className={`h-10 w-10 rounded-xl ${stat.bgColor} flex items-center justify-center`}>
                <Icon className={`h-5 w-5 ${stat.color}`} />
              </div>
              <div className="flex items-center gap-1 text-xs font-medium">
                {stat.trend === "up" && (
                  <>
                    <TrendingUp className="h-3.5 w-3.5 text-emerald-500" />
                    <span className="text-emerald-600 dark:text-emerald-400">{stat.change}</span>
                  </>
                )}
                {stat.trend === "down" && (
                  <>
                    <TrendingDown className="h-3.5 w-3.5 text-red-500" />
                    <span className="text-red-600 dark:text-red-400">{stat.change}</span>
                  </>
                )}
                {stat.trend === "neutral" && (
                  <span className="text-muted-foreground">{stat.change}</span>
                )}
              </div>
            </div>

            <div>
              <p className="text-2xl font-display font-bold tracking-tight">{stat.value}</p>
              <p className="text-xs text-muted-foreground mt-1">{stat.label}</p>
              <p className="text-xs text-muted-foreground/70">{stat.period}</p>
            </div>
          </div>
        )
      })}
    </div>
  )
}
