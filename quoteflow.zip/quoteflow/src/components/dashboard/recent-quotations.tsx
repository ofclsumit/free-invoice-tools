import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowRight } from "lucide-react"
import { cn } from "@/lib/utils"

const recentQuotes = [
  { id: "QUO-0023", client: "Future Tech Corp", amount: "₹3,40,000", validUntil: "25 Mar", status: "sent" },
  { id: "QUO-0022", client: "Modi Builders", amount: "₹87,500", validUntil: "20 Mar", status: "accepted" },
  { id: "QUO-0021", client: "Sunrise Hotels", amount: "₹1,65,000", validUntil: "15 Mar", status: "expired" },
  { id: "QUO-0020", client: "KP Associates", amount: "₹42,000", validUntil: "10 Apr", status: "draft" },
]

const statusConfig: Record<string, { label: string; className: string }> = {
  draft: { label: "Draft", className: "status-draft" },
  sent: { label: "Sent", className: "status-sent" },
  accepted: { label: "Accepted", className: "status-accepted" },
  rejected: { label: "Rejected", className: "status-rejected" },
  expired: { label: "Expired", className: "status-expired" },
  converted: { label: "Converted", className: "status-converted" },
}

export function RecentQuotations() {
  return (
    <div className="bg-white dark:bg-gray-900 rounded-2xl border border-border overflow-hidden h-full">
      <div className="flex items-center justify-between p-5 border-b border-border">
        <div>
          <h3 className="font-display font-semibold text-sm">Recent Quotations</h3>
          <p className="text-xs text-muted-foreground mt-0.5">Track your open quotes</p>
        </div>
        <Link href="/dashboard/quotations">
          <Button variant="ghost" size="sm" className="text-xs font-medium gap-1 h-7">
            View all <ArrowRight className="h-3 w-3" />
          </Button>
        </Link>
      </div>
      <div className="divide-y divide-border">
        {recentQuotes.map((q) => {
          const status = statusConfig[q.status]
          return (
            <Link key={q.id} href={`/dashboard/quotations/${q.id}`} className="flex items-center gap-3 px-5 py-3.5 hover:bg-gray-50/50 dark:hover:bg-gray-800/50 transition-colors">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-mono text-xs text-muted-foreground">{q.id}</span>
                </div>
                <p className="font-medium text-xs mt-0.5 truncate">{q.client}</p>
                <p className="text-xs text-muted-foreground">Valid: {q.validUntil}</p>
              </div>
              <div className="text-right flex-shrink-0 space-y-1">
                <p className="font-display font-semibold text-xs">{q.amount}</p>
                <Badge
                  variant="outline"
                  className={cn("text-xs px-1.5 py-0 h-4 border capitalize text-[10px]", status.className)}
                >
                  {status.label}
                </Badge>
              </div>
            </Link>
          )
        })}
      </div>
    </div>
  )
}
