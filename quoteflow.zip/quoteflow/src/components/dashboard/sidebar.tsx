"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import {
  LayoutDashboard,
  FileText,
  ClipboardList,
  Users,
  Settings,
  Zap,
  ChevronLeft,
  ChevronRight,
  Calculator,
  BarChart3,
  Palette,
} from "lucide-react"
import { useState } from "react"
import { Button } from "@/components/ui/button"

const navGroups = [
  {
    label: "Main",
    items: [
      { href: "/dashboard", icon: LayoutDashboard, label: "Dashboard" },
      { href: "/dashboard/invoices", icon: FileText, label: "Invoices" },
      { href: "/dashboard/quotations", icon: ClipboardList, label: "Quotations" },
      { href: "/dashboard/clients", icon: Users, label: "Clients" },
    ],
  },
  {
    label: "Analytics",
    items: [
      { href: "/dashboard/reports", icon: BarChart3, label: "Reports" },
    ],
  },
  {
    label: "Customise",
    items: [
      { href: "/dashboard/templates", icon: Palette, label: "Templates" },
      { href: "/dashboard/settings", icon: Settings, label: "Settings" },
    ],
  },
  {
    label: "Free Tools",
    items: [
      { href: "/tools/gst-calculator", icon: Calculator, label: "GST Calculator" },
    ],
  },
]

export function DashboardSidebar() {
  const pathname = usePathname()
  const [collapsed, setCollapsed] = useState(false)

  return (
    <aside
      className={cn(
        "hidden md:flex flex-col border-r border-border bg-white dark:bg-gray-900 transition-all duration-300 relative",
        collapsed ? "w-16" : "w-60"
      )}
    >
      {/* Logo */}
      <div className={cn("flex h-16 items-center border-b border-border px-4", collapsed && "justify-center px-2")}>
        <Link href="/dashboard" className="flex items-center gap-2.5 font-display font-bold min-w-0">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-blue-600 to-violet-600 shadow-sm flex-shrink-0">
            <Zap className="h-4 w-4 text-white" />
          </div>
          {!collapsed && (
            <span className="bg-gradient-to-r from-blue-600 to-violet-600 bg-clip-text text-transparent text-base truncate">
              QuoteFlow
            </span>
          )}
        </Link>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-4 px-2 space-y-6">
        {navGroups.map((group) => (
          <div key={group.label}>
            {!collapsed && (
              <p className="px-3 mb-1.5 text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">
                {group.label}
              </p>
            )}
            <ul className="space-y-0.5">
              {group.items.map((item) => {
                const Icon = item.icon
                const isActive = item.href === "/dashboard"
                  ? pathname === "/dashboard"
                  : pathname.startsWith(item.href)

                return (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      className={cn(
                        "nav-item",
                        isActive && "active",
                        collapsed && "justify-center px-2"
                      )}
                      title={collapsed ? item.label : undefined}
                    >
                      <Icon className="h-4 w-4 flex-shrink-0" />
                      {!collapsed && <span className="truncate">{item.label}</span>}
                    </Link>
                  </li>
                )
              })}
            </ul>
          </div>
        ))}
      </nav>

      {/* Collapse toggle */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="absolute -right-3 top-20 h-6 w-6 rounded-full border border-border bg-white dark:bg-gray-900 shadow-sm flex items-center justify-center hover:bg-accent transition-colors z-10"
        aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
      >
        {collapsed ? (
          <ChevronRight className="h-3 w-3" />
        ) : (
          <ChevronLeft className="h-3 w-3" />
        )}
      </button>

      {/* Quick create */}
      {!collapsed && (
        <div className="p-4 border-t border-border">
          <Link href="/dashboard/invoices/new">
            <Button
              size="sm"
              className="w-full bg-gradient-to-r from-blue-600 to-violet-600 text-white border-0 font-semibold text-xs"
            >
              + New Invoice
            </Button>
          </Link>
        </div>
      )}
    </aside>
  )
}
