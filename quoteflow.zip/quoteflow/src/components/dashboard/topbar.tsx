"use client"

import { Bell, Search, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ThemeToggle } from "@/components/shared/theme-toggle"
import { UserMenu } from "@/components/shared/user-menu"
import Link from "next/link"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

export function DashboardTopbar() {
  return (
    <header className="h-16 border-b border-border bg-white dark:bg-gray-900 flex items-center gap-4 px-4 sm:px-6 flex-shrink-0">
      {/* Search */}
      <div className="flex-1 max-w-md relative hidden sm:block">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search invoices, clients..."
          className="pl-9 h-9 bg-gray-50 dark:bg-gray-800 border-border text-sm"
        />
      </div>

      <div className="flex items-center gap-2 ml-auto">
        {/* Quick create */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              size="sm"
              className="h-8 bg-gradient-to-r from-blue-600 to-violet-600 text-white border-0 font-semibold"
            >
              <Plus className="h-4 w-4 mr-1.5" />
              <span className="hidden sm:inline">Create new</span>
              <span className="sm:hidden">New</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            <DropdownMenuItem asChild>
              <Link href="/dashboard/invoices/new" className="cursor-pointer">
                New Invoice
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link href="/dashboard/quotations/new" className="cursor-pointer">
                New Quotation
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link href="/dashboard/clients/new" className="cursor-pointer">
                Add Client
              </Link>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <Button variant="ghost" size="icon" className="h-8 w-8 relative">
          <Bell className="h-4 w-4" />
          <span className="absolute top-1 right-1 h-2 w-2 rounded-full bg-red-500" />
        </Button>

        <ThemeToggle />
        <UserMenu />
      </div>
    </header>
  )
}
