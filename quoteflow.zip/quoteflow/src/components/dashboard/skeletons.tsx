export function StatsSkeleton() {
  return (
    <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-4">
      {[1, 2, 3, 4].map((i) => (
        <div key={i} className="rounded-2xl border bg-card p-6 space-y-4">
          <div className="flex justify-between">
            <div className="h-10 w-10 rounded-xl shimmer" />
            <div className="h-4 w-16 rounded shimmer" />
          </div>
          <div className="space-y-2">
            <div className="h-7 w-28 rounded shimmer" />
            <div className="h-3 w-20 rounded shimmer" />
          </div>
        </div>
      ))}
    </div>
  )
}

export function TableSkeleton({ rows = 5 }: { rows?: number }) {
  return (
    <div className="space-y-3">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="h-14 rounded-xl shimmer" />
      ))}
    </div>
  )
}
