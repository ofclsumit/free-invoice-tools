import Link from "next/link"
import { Button } from "@/components/ui/button"
import { FileText, ClipboardList, Users } from "lucide-react"

export function QuickActions() {
  return (
    <div className="flex items-center gap-2">
      <Link href="/dashboard/invoices/new">
        <Button size="sm" className="h-9 gap-1.5 bg-gradient-to-r from-blue-600 to-violet-600 text-white border-0 font-semibold shadow-sm">
          <FileText className="h-3.5 w-3.5" />
          New Invoice
        </Button>
      </Link>
      <Link href="/dashboard/quotations/new">
        <Button size="sm" variant="outline" className="h-9 gap-1.5 font-medium">
          <ClipboardList className="h-3.5 w-3.5" />
          New Quote
        </Button>
      </Link>
      <Link href="/dashboard/clients/new" className="hidden sm:block">
        <Button size="sm" variant="ghost" className="h-9 gap-1.5 font-medium">
          <Users className="h-3.5 w-3.5" />
          Add Client
        </Button>
      </Link>
    </div>
  )
}
