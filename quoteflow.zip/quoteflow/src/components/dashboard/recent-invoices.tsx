import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, ExternalLink } from "lucide-react"
import { cn } from "@/lib/utils"

const recentInvoices = [
  { id: "INV-0047", client: "Ravi Enterprises", amount: "₹59,000", date: "15 Mar 2024", status: "paid", daysAgo: "2 days ago" },
  { id: "INV-0046", client: "Sharma & Sons", amount: "₹1,24,500", date: "12 Mar 2024", status: "sent", daysAgo: "5 days ago" },
  { id: "INV-0045", client: "Tech Solutions Pvt", amount: "₹87,200", date: "10 Mar 2024", status: "viewed", daysAgo: "7 days ago" },
  { id: "INV-0044", client: "Global Traders", amount: "₹34,800", date: "8 Mar 2024", status: "overdue", daysAgo: "9 days ago" },
  { id: "INV-0043", client: "Patel Industries", amount: "₹2,15,000", date: "5 Mar 2024", status: "paid", daysAgo: "12 days ago" },
]

const statusConfig: Record<string, { label: string; className: string }> = {
  draft: { label: "Draft", className: "status-draft" },
  sent: { label: "Sent", className: "status-sent" },
  viewed: { label: "Viewed", className: "status-viewed" },
  paid: { label: "Paid", className: "status-paid" },
  overdue: { label: "Overdue", className: "status-overdue" },
}

export function RecentInvoices() {
  return (
    <div className="bg-white dark:bg-gray-900 rounded-2xl border border-border overflow-hidden">
      <div className="flex items-center justify-between p-6 border-b border-border">
        <div>
          <h3 className="font-display font-semibold">Recent Invoices</h3>
          <p className="text-xs text-muted-foreground mt-0.5">Latest invoice activity</p>
        </div>
        <Link href="/dashboard/invoices">
          <Button variant="ghost" size="sm" className="text-xs font-medium gap-1.5">
            View all <ArrowRight className="h-3.5 w-3.5" />
          </Button>
        </Link>
      </div>

      <div className="divide-y divide-border">
        {recentInvoices.map((inv) => {
          const status = statusConfig[inv.status]
          return (
            <div key={inv.id} className="flex items-center gap-4 px-6 py-4 hover:bg-gray-50/50 dark:hover:bg-gray-800/50 transition-colors group">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs text-muted-foreground">{inv.id}</span>
                  <Badge
                    variant="outline"
                    className={cn("text-xs px-2 py-0 h-5 border capitalize", status.className)}
                  >
                    {status.label}
                  </Badge>
                </div>
                <p className="font-medium text-sm mt-0.5 truncate">{inv.client}</p>
                <p className="text-xs text-muted-foreground">{inv.daysAgo}</p>
              </div>
              <div className="text-right flex-shrink-0">
                <p className="font-display font-semibold text-sm">{inv.amount}</p>
                <p className="text-xs text-muted-foreground">{inv.date}</p>
              </div>
              <Link href={`/dashboard/invoices/${inv.id}`}>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <ExternalLink className="h-3.5 w-3.5" />
                </Button>
              </Link>
            </div>
          )
        })}
      </div>
    </div>
  )
}
