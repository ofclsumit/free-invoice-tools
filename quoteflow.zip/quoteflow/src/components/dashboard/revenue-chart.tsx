"use client"

import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts"

const data = [
  { month: "Aug", revenue: 180000, invoices: 28 },
  { month: "Sep", revenue: 220000, invoices: 35 },
  { month: "Oct", revenue: 195000, invoices: 31 },
  { month: "Nov", revenue: 310000, invoices: 42 },
  { month: "Dec", revenue: 285000, invoices: 38 },
  { month: "Jan", revenue: 420000, invoices: 52 },
  { month: "Feb", revenue: 380000, invoices: 45 },
  { month: "Mar", revenue: 482000, invoices: 47 },
]

const formatCurrency = (value: number) => {
  if (value >= 100000) return `₹${(value / 100000).toFixed(1)}L`
  if (value >= 1000) return `₹${(value / 1000).toFixed(0)}K`
  return `₹${value}`
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white dark:bg-gray-900 border border-border rounded-xl shadow-lg p-3 text-xs">
        <p className="font-display font-semibold mb-2">{label}</p>
        <p className="text-emerald-600">Revenue: ₹{payload[0]?.value?.toLocaleString("en-IN")}</p>
        <p className="text-blue-600">Invoices: {payload[1]?.value}</p>
      </div>
    )
  }
  return null
}

export function RevenueChart() {
  return (
    <div className="bg-white dark:bg-gray-900 rounded-2xl border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="font-display font-semibold">Revenue Overview</h3>
          <p className="text-xs text-muted-foreground mt-0.5">Last 8 months</p>
        </div>
        <div className="flex items-center gap-4 text-xs">
          <span className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-emerald-500" />
            Revenue
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-blue-500" />
            Invoices
          </span>
        </div>
      </div>
      <ResponsiveContainer width="100%" height={220}>
        <AreaChart data={data} margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#10b981" stopOpacity={0.15} />
              <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" className="stroke-border" vertical={false} />
          <XAxis
            dataKey="month"
            tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
            axisLine={false}
            tickLine={false}
          />
          <YAxis
            tickFormatter={formatCurrency}
            tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
            axisLine={false}
            tickLine={false}
            width={50}
          />
          <Tooltip content={<CustomTooltip />} />
          <Area
            type="monotone"
            dataKey="revenue"
            stroke="#10b981"
            strokeWidth={2}
            fill="url(#revenueGradient)"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  )
}
