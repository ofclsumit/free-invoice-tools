"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { CheckCircle2, Zap } from "lucide-react"
import { Badge } from "@/components/ui/badge"

const plans = [
  {
    name: "Free",
    price: "₹0",
    period: "forever",
    description: "Perfect for freelancers just getting started",
    badge: null,
    features: [
      "25 invoices / month",
      "10 quotations / month",
      "5 clients",
      "PDF download",
      "WhatsApp sharing",
      "GST calculator",
      "Basic templates",
    ],
    cta: "Start for free",
    href: "/auth/signup",
    variant: "outline" as const,
    highlight: false,
  },
  {
    name: "Pro",
    price: "₹299",
    period: "per month",
    description: "For growing businesses that need more power",
    badge: "Most Popular",
    features: [
      "Unlimited invoices",
      "Unlimited quotations",
      "Unlimited clients",
      "All templates",
      "UPI QR code generation",
      "Digital signature",
      "Email invoices",
      "Custom branding",
      "Excel / CSV export",
      "Priority support",
    ],
    cta: "Start 14-day free trial",
    href: "/auth/signup?plan=pro",
    variant: "default" as const,
    highlight: true,
  },
  {
    name: "Business",
    price: "₹799",
    period: "per month",
    description: "For teams and agencies managing multiple businesses",
    badge: null,
    features: [
      "Everything in Pro",
      "5 team members",
      "3 business profiles",
      "Advanced reports",
      "API access",
      "Custom domain links",
      "Dedicated support",
      "White-label PDF",
    ],
    cta: "Start 14-day free trial",
    href: "/auth/signup?plan=business",
    variant: "outline" as const,
    highlight: false,
  },
]

export function PricingSection() {
  return (
    <section id="pricing" className="py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <p className="text-sm font-semibold text-blue-600 dark:text-blue-400 tracking-widest uppercase">
            Simple pricing
          </p>
          <h2 className="text-3xl sm:text-4xl font-display font-bold tracking-tight">
            Plans that grow with you
          </h2>
          <p className="text-lg text-muted-foreground max-w-xl mx-auto">
            Start free. Upgrade when you need more. No hidden fees, no surprises.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`relative rounded-2xl border p-8 flex flex-col ${
                plan.highlight
                  ? "border-blue-500 bg-gradient-to-b from-blue-50 to-white dark:from-blue-950/30 dark:to-gray-900 shadow-xl shadow-blue-500/10"
                  : "border-border bg-card"
              }`}
            >
              {plan.badge && (
                <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-blue-600 to-violet-600 text-white border-0 px-4 py-1">
                  {plan.badge}
                </Badge>
              )}

              <div className="space-y-2 mb-6">
                <p className="font-display font-bold text-sm text-muted-foreground uppercase tracking-wider">{plan.name}</p>
                <div className="flex items-end gap-2">
                  <span className="font-display font-bold text-4xl">{plan.price}</span>
                  <span className="text-muted-foreground text-sm pb-1">/{plan.period}</span>
                </div>
                <p className="text-sm text-muted-foreground">{plan.description}</p>
              </div>

              <ul className="space-y-3 flex-1 mb-8">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2.5">
                    <CheckCircle2 className={`h-4 w-4 mt-0.5 flex-shrink-0 ${plan.highlight ? "text-blue-600" : "text-emerald-500"}`} />
                    <span className="text-sm">{f}</span>
                  </li>
                ))}
              </ul>

              <Link href={plan.href}>
                <Button
                  className={`w-full font-semibold ${plan.highlight ? "bg-gradient-to-r from-blue-600 to-violet-600 text-white border-0 shadow-lg shadow-blue-500/25" : ""}`}
                  variant={plan.highlight ? "default" : "outline"}
                >
                  {plan.highlight && <Zap className="h-4 w-4 mr-2" />}
                  {plan.cta}
                </Button>
              </Link>
            </div>
          ))}
        </div>

        <p className="text-center text-sm text-muted-foreground mt-8">
          All plans include 14-day free trial on paid tiers. No credit card required to start.
        </p>
      </div>
    </section>
  )
}
