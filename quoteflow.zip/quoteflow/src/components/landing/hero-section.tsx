"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { 
  ArrowRight, 
  CheckCircle2, 
  Zap,
  Download,
  Share2,
  IndianRupee
} from "lucide-react"

const benefits = [
  "Free forever — no credit card needed",
  "Instant PDF download",
  "WhatsApp & email sharing",
  "Works on mobile",
]

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-mesh pt-16">
      {/* Decorative blobs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-400/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-violet-400/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left: Copy */}
          <div className="text-center lg:text-left space-y-8">
            <div className="inline-flex">
              <Badge
                variant="outline"
                className="px-4 py-1.5 text-sm font-medium bg-blue-50 dark:bg-blue-950/50 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800 rounded-full gap-2"
              >
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500" />
                </span>
                India's fastest GST invoice generator
              </Badge>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-display font-bold leading-tight tracking-tight">
              Create GST Invoices{" "}
              <span className="relative">
                <span className="bg-gradient-to-r from-blue-600 via-violet-600 to-purple-600 bg-clip-text text-transparent">
                  in seconds
                </span>
                <svg
                  className="absolute -bottom-2 left-0 w-full"
                  viewBox="0 0 300 12"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M2 10C50 4 150 -2 298 8"
                    stroke="url(#underline-gradient)"
                    strokeWidth="3"
                    strokeLinecap="round"
                  />
                  <defs>
                    <linearGradient id="underline-gradient" x1="0" y1="0" x2="300" y2="0">
                      <stop stopColor="#2563eb" />
                      <stop offset="1" stopColor="#7c3aed" />
                    </linearGradient>
                  </defs>
                </svg>
              </span>
            </h1>

            <p className="text-lg sm:text-xl text-muted-foreground leading-relaxed max-w-xl mx-auto lg:mx-0">
              Professional GST invoices, quotations, and billing documents — built for Indian 
              freelancers and businesses. Faster than Zoho, simpler than Vyapar. 
              <strong className="text-foreground"> Free forever.</strong>
            </p>

            <ul className="space-y-2.5">
              {benefits.map((benefit) => (
                <li key={benefit} className="flex items-center gap-3 justify-center lg:justify-start">
                  <CheckCircle2 className="h-5 w-5 text-emerald-500 flex-shrink-0" />
                  <span className="text-sm text-muted-foreground">{benefit}</span>
                </li>
              ))}
            </ul>

            <div className="flex flex-col sm:flex-row gap-3 justify-center lg:justify-start">
              <Link href="/auth/signup">
                <Button
                  size="lg"
                  className="h-12 px-8 bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-700 hover:to-violet-700 text-white shadow-lg shadow-blue-500/25 border-0 font-semibold text-base"
                >
                  Create your first invoice
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Link href="/tools/invoice-generator">
                <Button size="lg" variant="outline" className="h-12 px-8 font-semibold text-base">
                  Try without signup
                </Button>
              </Link>
            </div>

            <p className="text-xs text-muted-foreground">
              No credit card · No watermarks · No hidden fees
            </p>
          </div>

          {/* Right: Invoice preview mockup */}
          <div className="relative hidden lg:block">
            <div className="relative z-10 bg-white dark:bg-gray-900 rounded-2xl shadow-2xl border border-border p-6 animate-fade-in">
              {/* Mock invoice */}
              <div className="space-y-4">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="h-8 w-24 rounded-lg bg-gradient-to-r from-blue-600 to-violet-600 flex items-center justify-center mb-3">
                      <Zap className="h-4 w-4 text-white" />
                    </div>
                    <p className="font-display font-bold text-sm text-foreground">Acme Design Studio</p>
                    <p className="text-xs text-muted-foreground">GSTIN: 27ABCDE1234F1Z5</p>
                  </div>
                  <div className="text-right">
                    <p className="font-display font-bold text-lg text-foreground">INVOICE</p>
                    <p className="text-xs text-muted-foreground">#INV-2024-0042</p>
                    <Badge className="mt-1 bg-emerald-50 text-emerald-700 border-emerald-200 text-xs">Paid</Badge>
                  </div>
                </div>
                
                <div className="border-t border-dashed border-border pt-4 grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <p className="text-muted-foreground">Bill To</p>
                    <p className="font-semibold mt-0.5">Ravi Enterprises</p>
                    <p className="text-muted-foreground">Mumbai, Maharashtra</p>
                  </div>
                  <div className="text-right">
                    <p className="text-muted-foreground">Invoice Date</p>
                    <p className="font-semibold mt-0.5">15 Jan, 2024</p>
                    <p className="text-muted-foreground mt-1">Due: 15 Feb, 2024</p>
                  </div>
                </div>

                <table className="w-full text-xs">
                  <thead>
                    <tr className="bg-gray-50 dark:bg-gray-800 rounded-lg">
                      <th className="text-left p-2 text-muted-foreground font-medium">Item</th>
                      <th className="text-right p-2 text-muted-foreground font-medium">Qty</th>
                      <th className="text-right p-2 text-muted-foreground font-medium">Rate</th>
                      <th className="text-right p-2 text-muted-foreground font-medium">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {[
                      { item: "Logo Design", qty: 1, rate: "25,000", amount: "25,000" },
                      { item: "Brand Guidelines", qty: 1, rate: "15,000", amount: "15,000" },
                      { item: "Social Media Kit", qty: 5, rate: "2,000", amount: "10,000" },
                    ].map((row) => (
                      <tr key={row.item}>
                        <td className="p-2 font-medium">{row.item}</td>
                        <td className="p-2 text-right text-muted-foreground">{row.qty}</td>
                        <td className="p-2 text-right text-muted-foreground">₹{row.rate}</td>
                        <td className="p-2 text-right">₹{row.amount}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                <div className="border-t border-border pt-3 space-y-1.5">
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Subtotal</span><span>₹50,000</span>
                  </div>
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>CGST (9%)</span><span>₹4,500</span>
                  </div>
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>SGST (9%)</span><span>₹4,500</span>
                  </div>
                  <div className="flex justify-between font-display font-bold text-sm border-t border-border pt-2">
                    <span>Total</span>
                    <span className="text-blue-600 dark:text-blue-400">₹59,000</span>
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <Button size="sm" className="flex-1 h-8 text-xs bg-gradient-to-r from-blue-600 to-violet-600 text-white border-0">
                    <Download className="h-3 w-3 mr-1.5" /> PDF
                  </Button>
                  <Button size="sm" variant="outline" className="flex-1 h-8 text-xs">
                    <Share2 className="h-3 w-3 mr-1.5" /> Share
                  </Button>
                </div>
              </div>
            </div>

            {/* Floating stat cards */}
            <div className="absolute -left-8 top-16 glass-card px-4 py-3 shadow-glass animate-slide-in animation-delay-200">
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
                  <IndianRupee className="h-4 w-4 text-emerald-600" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Revenue (Mar)</p>
                  <p className="font-display font-bold text-sm">₹2,40,000</p>
                </div>
              </div>
            </div>

            <div className="absolute -right-6 bottom-20 glass-card px-4 py-3 shadow-glass animate-slide-in animation-delay-400">
              <div className="flex items-center gap-2">
                <div className="h-7 w-7 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                  <Zap className="h-3.5 w-3.5 text-blue-600" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Generated in</p>
                  <p className="font-display font-bold text-sm text-blue-600">45 seconds</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Social proof numbers */}
        <div className="mt-20 pt-12 border-t border-border grid grid-cols-2 sm:grid-cols-4 gap-8">
          {[
            { value: "50,000+", label: "Invoices created" },
            { value: "8,500+", label: "Active businesses" },
            { value: "₹120Cr+", label: "Invoiced amount" },
            { value: "4.9 / 5", label: "Average rating" },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <p className="font-display font-bold text-2xl sm:text-3xl text-foreground">{stat.value}</p>
              <p className="text-sm text-muted-foreground mt-1">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
